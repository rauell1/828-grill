import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

type Category = "Burgers" | "Sides" | "Drinks" | "Combos";

type MenuItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  imageUrl: string;
  available: boolean;
  featured?: boolean;
};

type CartLine = {
  item: MenuItem;
  quantity: number;
};

type User = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
};

type StoredUser = User & {
  password: string;
};

type Order = {
  id: string;
  userId: string;
  items: CartLine[];
  total: number;
  status: "paid" | "pending";
  stripeId: string;
  phone?: string;
  address?: string;
  createdAt: string;
};

const categories: Category[] = ["Burgers", "Sides", "Drinks", "Combos"];

const heroImage =
  "https://images.pexels.com/photos/8029532/pexels-photo-8029532.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=2000";

const menuItems: MenuItem[] = [
  {
    id: "burger-ember-classic",
    name: "Ember Classic",
    description: "Smash-seared beef, American cheese, pickles, grilled onions, 828 sauce.",
    price: 12.5,
    category: "Burgers",
    imageUrl:
      "https://images.pexels.com/photos/4628555/pexels-photo-4628555.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
    featured: true,
  },
  {
    id: "burger-smokestack-double",
    name: "Smokestack Double",
    description: "Two charred patties, smoked cheddar, bacon jam, crisp onions.",
    price: 16,
    category: "Burgers",
    imageUrl:
      "https://images.pexels.com/photos/33858065/pexels-photo-33858065.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
    featured: true,
  },
  {
    id: "burger-carolina-firehouse",
    name: "Carolina Firehouse",
    description: "Pepper jack, jalapeno slaw, smoky mustard, charred bun.",
    price: 14.75,
    category: "Burgers",
    imageUrl:
      "https://images.pexels.com/photos/9469654/pexels-photo-9469654.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "burger-backyard",
    name: "828 Backyard Burger",
    description: "Lettuce, tomato, onion, cheddar, house pickles, flame sauce.",
    price: 13.25,
    category: "Burgers",
    imageUrl:
      "https://images.pexels.com/photos/15476357/pexels-photo-15476357.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "side-loaded-fries",
    name: "Loaded Pit Fries",
    description: "Crispy fries, cheddar, chopped bacon, scallions, ember ranch.",
    price: 8.5,
    category: "Sides",
    imageUrl:
      "https://images.pexels.com/photos/31300953/pexels-photo-31300953.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
    featured: true,
  },
  {
    id: "side-corn",
    name: "Charred Street Corn",
    description: "Fire-roasted corn, lime crema, cotija, chile dust.",
    price: 6.75,
    category: "Sides",
    imageUrl:
      "https://images.pexels.com/photos/7219747/pexels-photo-7219747.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "side-slaw",
    name: "Smokehouse Slaw",
    description: "Cabbage, carrots, pepper vinegar, smoked paprika finish.",
    price: 4.75,
    category: "Sides",
    imageUrl:
      "https://images.pexels.com/photos/33068079/pexels-photo-33068079.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "side-onion-rings",
    name: "Onion Ring Stack",
    description: "Thick-cut rings, black pepper crust, orange chile dip.",
    price: 7.25,
    category: "Sides",
    imageUrl:
      "https://images.pexels.com/photos/31300961/pexels-photo-31300961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "drink-tea",
    name: "House Sweet Tea",
    description: "Cold brewed black tea, cane sugar, lemon.",
    price: 3.5,
    category: "Drinks",
    imageUrl:
      "https://images.pexels.com/photos/33068080/pexels-photo-33068080.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "drink-lemonade",
    name: "Ember Lemonade",
    description: "Fresh lemon, orange peel, ginger, crushed ice.",
    price: 4,
    category: "Drinks",
    imageUrl:
      "https://images.pexels.com/photos/14773005/pexels-photo-14773005.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "drink-cola",
    name: "Glass Bottle Cola",
    description: "Classic cola served cold with a lime wedge.",
    price: 3.75,
    category: "Drinks",
    imageUrl:
      "https://images.pexels.com/photos/31300961/pexels-photo-31300961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "drink-limeade",
    name: "Sparkling Limeade",
    description: "Lime, mineral bubbles, smoked salt rim.",
    price: 4.25,
    category: "Drinks",
    imageUrl:
      "https://images.pexels.com/photos/7219747/pexels-photo-7219747.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "combo-pitmaster",
    name: "Pitmaster Combo",
    description: "Ember Classic, loaded fries, and a house drink.",
    price: 20,
    category: "Combos",
    imageUrl:
      "https://images.pexels.com/photos/33068079/pexels-photo-33068079.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
    featured: true,
  },
  {
    id: "combo-family-fire-pack",
    name: "Family Fire Pack",
    description: "Four burgers, two fries, slaw, and four drinks.",
    price: 58,
    category: "Combos",
    imageUrl:
      "https://images.pexels.com/photos/33068080/pexels-photo-33068080.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
  {
    id: "combo-late-night-heat",
    name: "Late Night Heat",
    description: "Smokestack Double, onion rings, ember lemonade.",
    price: 24,
    category: "Combos",
    imageUrl:
      "https://images.pexels.com/photos/14773005/pexels-photo-14773005.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    available: true,
  },
];

const storageKeys = {
  cart: "828-grill-cart",
  user: "828-grill-user",
  users: "828-grill-users",
  orders: "828-grill-orders",
};

function safeLoad<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function makeId(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value);
}

function getSearchParam(name: string) {
  return new URLSearchParams(window.location.search).get(name);
}

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.16 },
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`${className} reveal ${visible ? "reveal-visible" : ""}`}>
      {children}
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState(() => window.location.pathname + window.location.search);
  const [cart, setCart] = useState<CartLine[]>(() => safeLoad<CartLine[]>(storageKeys.cart, []));
  const [user, setUser] = useState<User | null>(() => safeLoad<User | null>(storageKeys.user, null));
  const [users, setUsers] = useState<StoredUser[]>(() => safeLoad<StoredUser[]>(storageKeys.users, []));
  const [orders, setOrders] = useState<Order[]>(() => safeLoad<Order[]>(storageKeys.orders, []));
  const [toast, setToast] = useState("");

  const path = route.split("?")[0] || "/";
  const cartCount = cart.reduce((sum, line) => sum + line.quantity, 0);
  const subtotal = cart.reduce((sum, line) => sum + line.item.price * line.quantity, 0);

  useEffect(() => {
    const onPopState = () => setRoute(window.location.pathname + window.location.search);
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    window.localStorage.setItem(storageKeys.cart, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    window.localStorage.setItem(storageKeys.users, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    window.localStorage.setItem(storageKeys.orders, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    if (user) {
      window.localStorage.setItem(storageKeys.user, JSON.stringify(user));
    } else {
      window.localStorage.removeItem(storageKeys.user);
    }
  }, [user]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function navigate(to: string) {
    window.history.pushState(null, "", to);
    setRoute(window.location.pathname + window.location.search);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function scrollToHomeMenu() {
    if (path !== "/") {
      navigate("/");
      window.setTimeout(() => document.getElementById("featured-menu")?.scrollIntoView({ behavior: "smooth" }), 150);
      return;
    }
    document.getElementById("featured-menu")?.scrollIntoView({ behavior: "smooth" });
  }

  function addToCart(item: MenuItem) {
    setCart((current) => {
      const existing = current.find((line) => line.item.id === item.id);
      if (existing) {
        return current.map((line) =>
          line.item.id === item.id ? { ...line, quantity: line.quantity + 1 } : line,
        );
      }
      return [...current, { item, quantity: 1 }];
    });
    setToast(`${item.name} added to cart`);
  }

  function updateQuantity(itemId: string, quantity: number) {
    if (quantity <= 0) {
      setCart((current) => current.filter((line) => line.item.id !== itemId));
      return;
    }
    setCart((current) =>
      current.map((line) => (line.item.id === itemId ? { ...line, quantity } : line)),
    );
  }

  function logout() {
    setUser(null);
    setToast("Signed out");
    if (["/account", "/checkout"].includes(path)) navigate("/");
  }

  function beginCheckout() {
    if (!cart.length) {
      setToast("Add an item before checkout");
      navigate("/menu");
      return;
    }
    if (!user) {
      setToast("Sign in to continue checkout");
      navigate("/auth/login?next=/checkout");
      return;
    }
    navigate("/checkout");
  }

  function completeOrder(details: { phone?: string; address?: string }) {
    if (!user || !cart.length) return;
    const order: Order = {
      id: makeId("ord"),
      userId: user.id,
      items: cart,
      total: subtotal,
      status: "paid",
      stripeId: makeId("cs_test_828"),
      phone: details.phone,
      address: details.address,
      createdAt: new Date().toISOString(),
    };

    setOrders((current) => [order, ...current]);
    setCart([]);
    setToast("Payment confirmed");
    navigate(`/order/${order.id}?session_id=${order.stripeId}`);
  }

  const page = useMemo(() => {
    if (path === "/") {
      return <HomePage addToCart={addToCart} navigate={navigate} scrollToMenu={scrollToHomeMenu} />;
    }
    if (path === "/menu") {
      return <MenuPage addToCart={addToCart} />;
    }
    if (path === "/cart") {
      return (
        <CartPage
          cart={cart}
          subtotal={subtotal}
          updateQuantity={updateQuantity}
          beginCheckout={beginCheckout}
          navigate={navigate}
        />
      );
    }
    if (path === "/checkout") {
      return (
        <CheckoutPage
          user={user}
          cart={cart}
          subtotal={subtotal}
          completeOrder={completeOrder}
          navigate={navigate}
        />
      );
    }
    if (path === "/account") {
      return (
        <AccountPage
          user={user}
          setUser={setUser}
          setUsers={setUsers}
          orders={orders}
          navigate={navigate}
        />
      );
    }
    if (path === "/auth/login") {
      return (
        <LoginPage
          users={users}
          setUsers={setUsers}
          setUser={setUser}
          navigate={navigate}
          setToast={setToast}
        />
      );
    }
    if (path === "/auth/register") {
      return (
        <RegisterPage
          users={users}
          setUsers={setUsers}
          setUser={setUser}
          navigate={navigate}
          setToast={setToast}
        />
      );
    }
    if (path.startsWith("/order/")) {
      const orderId = path.replace("/order/", "");
      return <OrderPage order={orders.find((entry) => entry.id === orderId)} navigate={navigate} />;
    }
    return <NotFoundPage navigate={navigate} />;
  }, [cart, orders, path, subtotal, user, users]);

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#F5F0E8]">
      <Header
        cartCount={cartCount}
        user={user}
        path={path}
        navigate={navigate}
        logout={logout}
        beginCheckout={beginCheckout}
      />
      {page}
      <Footer navigate={navigate} />
      {toast ? (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 border border-[#E8531A]/40 bg-[#1A1A1A] px-5 py-3 text-sm font-semibold text-[#F5F0E8] shadow-[0_0_45px_rgba(232,83,26,0.25)]">
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function Header({
  cartCount,
  user,
  path,
  navigate,
  logout,
  beginCheckout,
}: {
  cartCount: number;
  user: User | null;
  path: string;
  navigate: (to: string) => void;
  logout: () => void;
  beginCheckout: () => void;
}) {
  const navItem = (href: string, label: string) => (
    <button
      type="button"
      onClick={() => navigate(href)}
      className={`text-sm font-semibold uppercase tracking-[0.22em] transition hover:text-[#E8531A] ${
        path === href ? "text-[#E8531A]" : "text-[#F5F0E8]/75"
      }`}
    >
      {label}
    </button>
  );

  return (
    <header className="fixed left-0 right-0 top-0 z-40 border-b border-white/10 bg-[#0D0D0D]/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => navigate("/")}
          className="font-display text-3xl tracking-[0.16em] text-[#F5F0E8] sm:text-4xl"
        >
          828 <span className="text-[#E8531A]">GRILL</span>
        </button>
        <nav className="hidden items-center gap-8 md:flex">
          {navItem("/menu", "Menu")}
          {navItem("/cart", "Cart")}
          {navItem("/account", "Account")}
        </nav>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate("/menu")}
            className="border border-white/15 px-3 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#F5F0E8] transition hover:border-[#E8531A]/60 hover:text-[#E8531A] md:hidden"
          >
            Menu
          </button>
          <button
            type="button"
            onClick={() => navigate("/cart")}
            className="relative border border-white/15 px-3 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#F5F0E8] transition hover:border-[#E8531A]/60 hover:text-[#E8531A] sm:px-4"
          >
            Cart
            <span className="ml-2 font-mono-brand text-[#E8531A]">{cartCount}</span>
          </button>
          {user ? (
            <button
              type="button"
              onClick={logout}
              className="hidden text-xs font-bold uppercase tracking-[0.18em] text-[#888888] transition hover:text-[#F5F0E8] sm:block"
            >
              Sign Out
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigate("/auth/login")}
              className="hidden text-xs font-bold uppercase tracking-[0.18em] text-[#888888] transition hover:text-[#F5F0E8] sm:block"
            >
              Sign In
            </button>
          )}
          <button
            type="button"
            onClick={beginCheckout}
            className="ember-button hidden px-4 py-3 text-xs font-extrabold uppercase tracking-[0.18em] text-white sm:block"
          >
            Checkout
          </button>
        </div>
      </div>
    </header>
  );
}

function HomePage({
  addToCart,
  navigate,
  scrollToMenu,
}: {
  addToCart: (item: MenuItem) => void;
  navigate: (to: string) => void;
  scrollToMenu: () => void;
}) {
  const featured = menuItems.filter((item) => item.featured);

  return (
    <main>
      <section className="relative flex min-h-screen items-end overflow-hidden px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        <div
          className="hero-photo absolute inset-0 scale-105 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(13,13,13,0.94),rgba(13,13,13,0.62)_45%,rgba(232,83,26,0.2)),linear-gradient(0deg,rgba(13,13,13,0.98),rgba(13,13,13,0.08)_42%,rgba(13,13,13,0.28))]" />
        <div className="ember-smoke absolute -left-24 top-28 h-64 w-64 rounded-full bg-[#E8531A]/20 blur-3xl" />
        <div className="relative z-10 mx-auto w-full max-w-7xl">
          <div className="max-w-4xl hero-copy">
            <p className="mb-4 font-mono-brand text-sm uppercase tracking-[0.38em] text-[#E8531A]">
              Asheville heat. Built to order.
            </p>
            <h1 className="font-display text-[5rem] leading-[0.82] tracking-[0.04em] text-[#F5F0E8] sm:text-[7.5rem] lg:text-[10.5rem]">
              828 GRILL
            </h1>
            <h2 className="mt-6 max-w-3xl font-display text-5xl leading-none tracking-[0.04em] text-[#F5F0E8]/95 sm:text-7xl">
              Fire-built burgers for serious appetites.
            </h2>
            <p className="mt-6 max-w-2xl text-base leading-8 text-[#F5F0E8]/72 sm:text-lg">
              Dark-char sears, smoky sauces, and hot-off-the-grill combos made for pickup or delivery.
            </p>
            <button
              type="button"
              onClick={scrollToMenu}
              className="ember-button mt-9 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
            >
              Order Now
            </button>
          </div>
        </div>
      </section>

      <section id="featured-menu" className="px-4 py-24 sm:px-6 lg:px-8">
        <Reveal className="mx-auto max-w-7xl">
          <div className="mb-12 max-w-3xl">
            <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Menu reveal</p>
            <h2 className="mt-3 font-display text-6xl leading-none text-[#F5F0E8] sm:text-8xl">
              House heat
            </h2>
            <p className="mt-4 text-lg leading-8 text-[#888888]">
              Start with the signatures, then build the cart your way.
            </p>
          </div>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {featured.map((item, index) => (
              <MenuItemCard key={item.id} item={item} addToCart={addToCart} index={index} />
            ))}
          </div>
        </Reveal>
      </section>

      <section className="border-y border-white/10 bg-[#1A1A1A]/45 px-4 py-24 sm:px-6 lg:px-8">
        <Reveal className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">The craft</p>
            <h2 className="mt-3 font-display text-6xl leading-none text-[#F5F0E8] sm:text-8xl">
              Smoke, sear, send it.
            </h2>
          </div>
          <p className="text-xl leading-9 text-[#F5F0E8]/72">
            828 Grill keeps the menu focused: burgers with real char, sides that can hold their own,
            and combos that move fast from grill to checkout. The experience is designed to feel as
            direct as the food: choose, cart, pay, confirm.
          </p>
        </Reveal>
      </section>

      <section className="px-4 py-24 sm:px-6 lg:px-8">
        <Reveal className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 sm:flex-row sm:items-end">
          <div className="max-w-3xl">
            <h2 className="font-display text-6xl leading-none text-[#F5F0E8] sm:text-8xl">Ready for fire?</h2>
            <p className="mt-4 text-lg text-[#888888]">Browse the full 828 Grill menu and checkout in minutes.</p>
          </div>
          <button
            type="button"
            onClick={() => navigate("/menu")}
            className="ember-button px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
          >
            Full Menu
          </button>
        </Reveal>
      </section>
    </main>
  );
}

function MenuPage({ addToCart }: { addToCart: (item: MenuItem) => void }) {
  const [activeCategory, setActiveCategory] = useState<Category | "All">("All");
  const filtered = activeCategory === "All" ? menuItems : menuItems.filter((item) => item.category === activeCategory);

  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Order online</p>
          <div className="mt-3 flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
            <div className="max-w-3xl">
              <h1 className="font-display text-7xl leading-none text-[#F5F0E8] sm:text-9xl">The menu</h1>
              <p className="mt-5 text-lg leading-8 text-[#888888]">
                Filter by category, add to cart, and continue to the checkout flow.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {["All", ...categories].map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveCategory(category as Category | "All")}
                  className={`border px-4 py-3 text-xs font-extrabold uppercase tracking-[0.18em] transition ${
                    activeCategory === category
                      ? "border-[#E8531A] bg-[#E8531A] text-white"
                      : "border-white/15 text-[#F5F0E8]/70 hover:border-[#E8531A]/60 hover:text-[#E8531A]"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </Reveal>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((item, index) => (
            <MenuItemCard key={item.id} item={item} addToCart={addToCart} index={index} />
          ))}
        </div>
      </div>
    </main>
  );
}

function MenuItemCard({
  item,
  addToCart,
  index,
}: {
  item: MenuItem;
  addToCart: (item: MenuItem) => void;
  index: number;
}) {
  return (
    <Reveal className="h-full" key={item.id}>
      <article
        className="group flex h-full flex-col overflow-hidden bg-[#1A1A1A] transition duration-500 hover:-translate-y-1 hover:bg-[#211814]"
        style={{ transitionDelay: `${Math.min(index, 5) * 45}ms` }}
      >
        <div className="relative h-56 overflow-hidden">
          <img
            src={item.imageUrl}
            alt={item.name}
            className="h-full w-full object-cover opacity-88 transition duration-700 group-hover:scale-105 group-hover:opacity-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D]/86 via-transparent to-transparent" />
          <div className="absolute bottom-4 left-4 font-mono-brand text-xs uppercase tracking-[0.26em] text-[#E8531A]">
            {item.category}
          </div>
        </div>
        <div className="flex flex-1 flex-col p-5">
          <div className="flex items-start justify-between gap-4">
            <h3 className="font-display text-4xl leading-none text-[#F5F0E8]">{item.name}</h3>
            <p className="font-mono-brand text-lg text-[#E8531A]">{formatCurrency(item.price)}</p>
          </div>
          <p className="mt-4 flex-1 text-sm leading-6 text-[#888888]">{item.description}</p>
          <button
            type="button"
            onClick={() => addToCart(item)}
            className="mt-6 border border-[#E8531A]/55 px-4 py-3 text-sm font-extrabold uppercase tracking-[0.18em] text-[#F5F0E8] transition hover:border-[#E8531A] hover:bg-[#E8531A] hover:text-white"
          >
            Add to cart
          </button>
        </div>
      </article>
    </Reveal>
  );
}

function CartPage({
  cart,
  subtotal,
  updateQuantity,
  beginCheckout,
  navigate,
}: {
  cart: CartLine[];
  subtotal: number;
  updateQuantity: (itemId: string, quantity: number) => void;
  beginCheckout: () => void;
  navigate: (to: string) => void;
}) {
  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Local cart</p>
          <h1 className="mt-3 font-display text-7xl leading-none text-[#F5F0E8] sm:text-9xl">Your order</h1>
        </Reveal>

        {!cart.length ? (
          <Reveal className="mt-12 border-y border-white/10 py-14">
            <p className="text-xl text-[#888888]">Your cart is empty. The grill is ready when you are.</p>
            <button
              type="button"
              onClick={() => navigate("/menu")}
              className="ember-button mt-8 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
            >
              Browse Menu
            </button>
          </Reveal>
        ) : (
          <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_360px]">
            <div className="divide-y divide-white/10 border-y border-white/10">
              {cart.map((line) => (
                <div key={line.item.id} className="grid gap-5 py-6 sm:grid-cols-[112px_1fr_auto] sm:items-center">
                  <img src={line.item.imageUrl} alt={line.item.name} className="h-28 w-28 object-cover" />
                  <div>
                    <p className="font-display text-4xl leading-none text-[#F5F0E8]">{line.item.name}</p>
                    <p className="mt-2 max-w-xl text-sm leading-6 text-[#888888]">{line.item.description}</p>
                    <p className="mt-2 font-mono-brand text-[#E8531A]">{formatCurrency(line.item.price)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => updateQuantity(line.item.id, line.quantity - 1)}
                      className="h-10 w-10 border border-white/15 text-xl transition hover:border-[#E8531A] hover:text-[#E8531A]"
                    >
                      -
                    </button>
                    <span className="w-8 text-center font-mono-brand text-lg">{line.quantity}</span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(line.item.id, line.quantity + 1)}
                      className="h-10 w-10 border border-white/15 text-xl transition hover:border-[#E8531A] hover:text-[#E8531A]"
                    >
                      +
                    </button>
                    <button
                      type="button"
                      onClick={() => updateQuantity(line.item.id, 0)}
                      className="ml-2 text-xs font-bold uppercase tracking-[0.18em] text-[#888888] transition hover:text-[#E8531A]"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <aside className="h-fit bg-[#1A1A1A] p-6">
              <p className="font-display text-4xl text-[#F5F0E8]">Summary</p>
              <div className="mt-6 space-y-4 border-y border-white/10 py-5 text-sm text-[#888888]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono-brand text-[#F5F0E8]">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated tax</span>
                  <span className="font-mono-brand text-[#F5F0E8]">Calculated by Stripe</span>
                </div>
              </div>
              <div className="mt-5 flex justify-between text-lg font-bold">
                <span>Total due</span>
                <span className="font-mono-brand text-[#E8531A]">{formatCurrency(subtotal)}</span>
              </div>
              <button
                type="button"
                onClick={beginCheckout}
                className="ember-button mt-7 w-full px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
              >
                Checkout
              </button>
            </aside>
          </div>
        )}
      </div>
    </main>
  );
}

function CheckoutPage({
  user,
  cart,
  subtotal,
  completeOrder,
  navigate,
}: {
  user: User | null;
  cart: CartLine[];
  subtotal: number;
  completeOrder: (details: { phone?: string; address?: string }) => void;
  navigate: (to: string) => void;
}) {
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [address, setAddress] = useState(user?.address ?? "");
  const [processing, setProcessing] = useState(false);

  if (!user) {
    return <AuthGate title="Checkout requires an account" navigate={navigate} next="/checkout" />;
  }

  if (!cart.length) {
    return (
      <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl border-y border-white/10 py-14">
          <h1 className="font-display text-7xl leading-none text-[#F5F0E8]">No active cart</h1>
          <p className="mt-4 text-lg text-[#888888]">Add menu items before opening checkout.</p>
          <button
            type="button"
            onClick={() => navigate("/menu")}
            className="ember-button mt-8 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
          >
            Browse Menu
          </button>
        </div>
      </main>
    );
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setProcessing(true);
    window.setTimeout(() => completeOrder({ phone, address }), 900);
  }

  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Stripe checkout simulation</p>
          <h1 className="mt-3 font-display text-7xl leading-none text-[#F5F0E8] sm:text-9xl">Checkout</h1>
        </Reveal>
        <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_360px]">
          <form onSubmit={handleSubmit} className="space-y-5">
            <Field label="Full name" value={user.name} readOnly />
            <Field label="Email" value={user.email} readOnly />
            <Field label="Phone number" value={phone} onChange={setPhone} placeholder="(555) 828-0000" />
            <label className="block">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.2em] text-[#888888]">
                Delivery address
              </span>
              <textarea
                value={address}
                onChange={(event) => setAddress(event.target.value)}
                placeholder="Street, city, state, ZIP"
                className="min-h-32 w-full border border-white/15 bg-[#1A1A1A] px-4 py-3 text-[#F5F0E8] outline-none transition placeholder:text-[#888888]/70 focus:border-[#E8531A]"
              />
            </label>
            <button
              type="submit"
              disabled={processing}
              className="ember-button w-full px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white disabled:cursor-wait disabled:opacity-60"
            >
              {processing ? "Opening Stripe" : "Continue to Stripe Checkout"}
            </button>
          </form>
          <aside className="h-fit bg-[#1A1A1A] p-6">
            <p className="font-display text-4xl text-[#F5F0E8]">Order lines</p>
            <div className="mt-6 divide-y divide-white/10 border-y border-white/10">
              {cart.map((line) => (
                <div key={line.item.id} className="flex justify-between gap-4 py-4 text-sm">
                  <div>
                    <p className="font-semibold text-[#F5F0E8]">{line.item.name}</p>
                    <p className="mt-1 text-[#888888]">Qty {line.quantity}</p>
                  </div>
                  <p className="font-mono-brand text-[#E8531A]">{formatCurrency(line.item.price * line.quantity)}</p>
                </div>
              ))}
            </div>
            <div className="mt-5 flex justify-between text-lg font-bold">
              <span>Total</span>
              <span className="font-mono-brand text-[#E8531A]">{formatCurrency(subtotal)}</span>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}

function AccountPage({
  user,
  setUser,
  setUsers,
  orders,
  navigate,
}: {
  user: User | null;
  setUser: (user: User) => void;
  setUsers: React.Dispatch<React.SetStateAction<StoredUser[]>>;
  orders: Order[];
  navigate: (to: string) => void;
}) {
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [address, setAddress] = useState(user?.address ?? "");
  const accountOrders = orders.filter((order) => order.userId === user?.id);

  if (!user) {
    return <AuthGate title="Your account is protected" navigate={navigate} next="/account" />;
  }

  const currentUser = user;

  function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const updated: User = { ...currentUser, name, phone, address };
    setUser(updated);
    setUsers((current) => current.map((entry) => (entry.id === currentUser.id ? { ...entry, ...updated } : entry)));
  }

  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Signed in</p>
          <h1 className="mt-3 font-display text-7xl leading-none text-[#F5F0E8] sm:text-9xl">Account</h1>
        </Reveal>
        <div className="mt-12 grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <form onSubmit={saveProfile} className="space-y-5 bg-[#1A1A1A] p-6">
            <p className="font-display text-4xl text-[#F5F0E8]">Profile</p>
            <Field label="Full name" value={name} onChange={setName} required />
            <Field label="Email" value={user.email} readOnly />
            <Field label="Phone" value={phone} onChange={setPhone} />
            <label className="block">
              <span className="mb-2 block text-xs font-bold uppercase tracking-[0.2em] text-[#888888]">
                Saved delivery address
              </span>
              <textarea
                value={address}
                onChange={(event) => setAddress(event.target.value)}
                className="min-h-28 w-full border border-white/15 bg-[#0D0D0D] px-4 py-3 text-[#F5F0E8] outline-none transition focus:border-[#E8531A]"
              />
            </label>
            <button
              type="submit"
              className="border border-[#E8531A]/55 px-5 py-3 text-sm font-extrabold uppercase tracking-[0.18em] text-[#F5F0E8] transition hover:bg-[#E8531A] hover:text-white"
            >
              Save Profile
            </button>
          </form>
          <section>
            <p className="font-display text-4xl text-[#F5F0E8]">Order history</p>
            {accountOrders.length ? (
              <div className="mt-6 divide-y divide-white/10 border-y border-white/10">
                {accountOrders.map((order) => (
                  <button
                    key={order.id}
                    type="button"
                    onClick={() => navigate(`/order/${order.id}`)}
                    className="block w-full py-5 text-left transition hover:bg-white/[0.03]"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-mono-brand text-sm uppercase tracking-[0.2em] text-[#E8531A]">{order.id}</p>
                        <p className="mt-2 text-sm text-[#888888]">
                          {new Date(order.createdAt).toLocaleString()} - {order.items.length} item types
                        </p>
                      </div>
                      <div className="font-mono-brand text-lg text-[#F5F0E8]">{formatCurrency(order.total)}</div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="mt-6 border-y border-white/10 py-10 text-[#888888]">
                No completed orders yet. Place one from the menu.
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}

function LoginPage({
  users,
  setUsers,
  setUser,
  navigate,
  setToast,
}: {
  users: StoredUser[];
  setUsers: React.Dispatch<React.SetStateAction<StoredUser[]>>;
  setUser: (user: User) => void;
  navigate: (to: string) => void;
  setToast: (message: string) => void;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const next = getSearchParam("next") ?? "/account";

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const found = users.find(
      (entry) => entry.email.toLowerCase() === email.toLowerCase().trim() && entry.password === password,
    );
    if (!found) {
      setError("No matching account found. Register or use the demo Google sign-in.");
      return;
    }
    const { password: _password, ...safeUser } = found;
    setUser(safeUser);
    setToast("Signed in");
    navigate(next);
  }

  function continueWithGoogle() {
    const emailAddress = "guest@828grill.com";
    const existing = users.find((entry) => entry.email === emailAddress);
    if (existing) {
      const { password: _password, ...safeUser } = existing;
      setUser(safeUser);
    } else {
      const googleUser: StoredUser = {
        id: makeId("usr"),
        name: "Google Guest",
        email: emailAddress,
        phone: "",
        address: "",
        password: "google-oauth-demo",
      };
      setUsers((current) => [...current, googleUser]);
      const { password: _password, ...safeUser } = googleUser;
      setUser(safeUser);
    }
    setToast("Google sign-in connected");
    navigate(next);
  }

  return (
    <AuthShell title="Login" eyebrow="Credentials plus Google OAuth" navigate={navigate}>
      <form onSubmit={handleSubmit} className="space-y-5">
        <Field label="Email" type="email" value={email} onChange={setEmail} required />
        <Field label="Password" type="password" value={password} onChange={setPassword} required />
        {error ? <p className="text-sm text-[#E8531A]">{error}</p> : null}
        <button
          type="submit"
          className="ember-button w-full px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
        >
          Sign In
        </button>
      </form>
      <button
        type="button"
        onClick={continueWithGoogle}
        className="mt-4 w-full border border-white/15 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.18em] text-[#F5F0E8] transition hover:border-[#E8531A] hover:text-[#E8531A]"
      >
        Continue with Google
      </button>
      <p className="mt-6 text-sm text-[#888888]">
        New here?{" "}
        <button type="button" onClick={() => navigate(`/auth/register?next=${next}`)} className="text-[#E8531A]">
          Create an account
        </button>
      </p>
    </AuthShell>
  );
}

function RegisterPage({
  users,
  setUsers,
  setUser,
  navigate,
  setToast,
}: {
  users: StoredUser[];
  setUsers: React.Dispatch<React.SetStateAction<StoredUser[]>>;
  setUser: (user: User) => void;
  navigate: (to: string) => void;
  setToast: (message: string) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState("");
  const next = getSearchParam("next") ?? "/account";

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalizedEmail = email.toLowerCase().trim();
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (users.some((entry) => entry.email.toLowerCase() === normalizedEmail)) {
      setError("That email is already registered.");
      return;
    }
    const created: StoredUser = {
      id: makeId("usr"),
      name,
      email: normalizedEmail,
      password,
      phone,
      address,
    };
    setUsers((current) => [...current, created]);
    const { password: _password, ...safeUser } = created;
    setUser(safeUser);
    setToast("Account created");
    navigate(next);
  }

  return (
    <AuthShell title="Register" eyebrow="New 828 Grill account" navigate={navigate}>
      <form onSubmit={handleSubmit} className="space-y-5">
        <Field label="Full name" value={name} onChange={setName} required />
        <Field label="Email" type="email" value={email} onChange={setEmail} required />
        <Field label="Password" type="password" value={password} onChange={setPassword} required />
        <Field label="Phone number" value={phone} onChange={setPhone} />
        <label className="block">
          <span className="mb-2 block text-xs font-bold uppercase tracking-[0.2em] text-[#888888]">
            Delivery address
          </span>
          <textarea
            value={address}
            onChange={(event) => setAddress(event.target.value)}
            className="min-h-28 w-full border border-white/15 bg-[#0D0D0D] px-4 py-3 text-[#F5F0E8] outline-none transition focus:border-[#E8531A]"
          />
        </label>
        {error ? <p className="text-sm text-[#E8531A]">{error}</p> : null}
        <button
          type="submit"
          className="ember-button w-full px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
        >
          Create Account
        </button>
      </form>
      <p className="mt-6 text-sm text-[#888888]">
        Already registered?{" "}
        <button type="button" onClick={() => navigate(`/auth/login?next=${next}`)} className="text-[#E8531A]">
          Sign in
        </button>
      </p>
    </AuthShell>
  );
}

function OrderPage({ order, navigate }: { order?: Order; navigate: (to: string) => void }) {
  if (!order) {
    return (
      <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl border-y border-white/10 py-14">
          <h1 className="font-display text-7xl leading-none text-[#F5F0E8]">Order not found</h1>
          <p className="mt-4 text-lg text-[#888888]">This confirmation is not available in local storage.</p>
          <button
            type="button"
            onClick={() => navigate("/menu")}
            className="ember-button mt-8 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
          >
            Return to Menu
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        <Reveal>
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">Payment confirmed</p>
          <h1 className="mt-3 font-display text-7xl leading-none text-[#F5F0E8] sm:text-9xl">Order fired</h1>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-[#888888]">
            Your 828 Grill order has been marked paid and sent to the kitchen queue.
          </p>
        </Reveal>
        <section className="mt-12 bg-[#1A1A1A] p-6">
          <div className="flex flex-col gap-4 border-b border-white/10 pb-6 sm:flex-row sm:justify-between">
            <div>
              <p className="font-mono-brand text-sm uppercase tracking-[0.22em] text-[#E8531A]">{order.id}</p>
              <p className="mt-2 text-sm text-[#888888]">Stripe session: {order.stripeId}</p>
            </div>
            <p className="font-mono-brand text-2xl text-[#F5F0E8]">{formatCurrency(order.total)}</p>
          </div>
          <div className="divide-y divide-white/10">
            {order.items.map((line) => (
              <div key={line.item.id} className="flex justify-between gap-4 py-5">
                <div>
                  <p className="font-display text-3xl text-[#F5F0E8]">{line.item.name}</p>
                  <p className="text-sm text-[#888888]">Quantity {line.quantity}</p>
                </div>
                <p className="font-mono-brand text-[#E8531A]">{formatCurrency(line.item.price * line.quantity)}</p>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={() => navigate("/menu")}
            className="ember-button mt-6 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
          >
            Order Again
          </button>
        </section>
      </div>
    </main>
  );
}

function AuthGate({ title, navigate, next }: { title: string; navigate: (to: string) => void; next: string }) {
  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl border-y border-white/10 py-14">
        <h1 className="font-display text-7xl leading-none text-[#F5F0E8]">{title}</h1>
        <p className="mt-4 text-lg text-[#888888]">Sign in or register to continue.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => navigate(`/auth/login?next=${next}`)}
            className="ember-button px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => navigate(`/auth/register?next=${next}`)}
            className="border border-white/15 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-[#F5F0E8] transition hover:border-[#E8531A] hover:text-[#E8531A]"
          >
            Register
          </button>
        </div>
      </div>
    </main>
  );
}

function AuthShell({
  title,
  eyebrow,
  navigate,
  children,
}: {
  title: string;
  eyebrow: string;
  navigate: (to: string) => void;
  children: React.ReactNode;
}) {
  return (
    <main className="grid min-h-screen lg:grid-cols-[0.9fr_1.1fr]">
      <section className="hidden overflow-hidden lg:block">
        <div className="relative h-full min-h-screen">
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroImage})` }} />
          <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(13,13,13,0.95),rgba(13,13,13,0.55)),linear-gradient(0deg,rgba(13,13,13,0.94),rgba(232,83,26,0.2))]" />
          <div className="relative z-10 flex h-full min-h-screen flex-col justify-end p-12">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="mb-10 text-left font-display text-8xl leading-none text-[#F5F0E8]"
            >
              828 <span className="text-[#E8531A]">GRILL</span>
            </button>
            <p className="max-w-md text-xl leading-8 text-[#F5F0E8]/72">
              Accounts keep addresses ready, orders saved, and checkout fast.
            </p>
          </div>
        </div>
      </section>
      <section className="flex items-center px-4 py-32 sm:px-6 lg:px-16">
        <div className="mx-auto w-full max-w-md">
          <p className="font-mono-brand text-sm uppercase tracking-[0.32em] text-[#E8531A]">{eyebrow}</p>
          <h1 className="mt-3 font-display text-7xl leading-none text-[#F5F0E8] sm:text-8xl">{title}</h1>
          <div className="mt-10 bg-[#1A1A1A] p-6">{children}</div>
        </div>
      </section>
    </main>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
  readOnly = false,
  placeholder,
}: {
  label: string;
  value: string;
  onChange?: (value: string) => void;
  type?: string;
  required?: boolean;
  readOnly?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold uppercase tracking-[0.2em] text-[#888888]">{label}</span>
      <input
        type={type}
        value={value}
        required={required}
        readOnly={readOnly}
        placeholder={placeholder}
        onChange={(event) => onChange?.(event.target.value)}
        className="w-full border border-white/15 bg-[#0D0D0D] px-4 py-3 text-[#F5F0E8] outline-none transition placeholder:text-[#888888]/70 focus:border-[#E8531A] read-only:text-[#888888]"
      />
    </label>
  );
}

function NotFoundPage({ navigate }: { navigate: (to: string) => void }) {
  return (
    <main className="px-4 pb-24 pt-36 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl border-y border-white/10 py-14">
        <h1 className="font-display text-7xl leading-none text-[#F5F0E8]">Page not found</h1>
        <p className="mt-4 text-lg text-[#888888]">The requested 828 Grill route does not exist.</p>
        <button
          type="button"
          onClick={() => navigate("/")}
          className="ember-button mt-8 px-7 py-4 text-sm font-extrabold uppercase tracking-[0.22em] text-white"
        >
          Go Home
        </button>
      </div>
    </main>
  );
}

function Footer({ navigate }: { navigate: (to: string) => void }) {
  return (
    <footer className="border-t border-white/10 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-5 text-sm text-[#888888] sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-4xl text-[#F5F0E8]">828 <span className="text-[#E8531A]">GRILL</span></p>
          <p className="mt-1">Dark grill-house ordering prototype for 828 Grill LLC.</p>
        </div>
        <div className="flex flex-wrap gap-5">
          <button type="button" onClick={() => navigate("/menu")} className="transition hover:text-[#E8531A]">
            Menu
          </button>
          <button type="button" onClick={() => navigate("/cart")} className="transition hover:text-[#E8531A]">
            Cart
          </button>
          <a href="https://www.instagram.com/828grill" className="transition hover:text-[#E8531A]">
            @828grill
          </a>
        </div>
      </div>
    </footer>
  );
}